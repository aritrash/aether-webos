#include "utils.h"
#include "uart.h"
#include <stddef.h>


void* memset(void* s, int c, size_t n) {
    volatile unsigned char* p = (volatile unsigned char*)s;
    while (n--) {
        *p++ = (unsigned char)c;
    }
    return s;
}

void *memcpy(void *dest, const void *src, size_t n) {
    char *d = dest;
    const char *s = src;
    while (n--) *d++ = *s++;
    return dest;
}

void str_clear(char* str) {
    if (str) str[0] = '\0';
}

void str_append(char* str, const char* data) {
    if (!str || !data) return;
    while (*str) str++; 
    while (*data) *str++ = *data++;
    *str = '\0';
}

/**
 * str_append_kv_int: Formats "key": value for JSON.
 */
void str_append_kv_int(char* str, const char* key, uint64_t value) {
    str_append(str, "\"");
    str_append(str, key);
    str_append(str, "\":");
    
    char buf[21];
    int i = 0;
    if (value == 0) {
        buf[i++] = '0';
    } else {
        while (value > 0) {
            buf[i++] = (value % 10) + '0';
            value /= 10;
        }
    }
    
    // Reverse the string for correct order
    for (int j = 0; j < i / 2; j++) {
        char tmp = buf[j];
        buf[j] = buf[i - j - 1];
        buf[i - j - 1] = tmp;
    }
    buf[i] = '\0';
    
    str_append(str, buf);
    str_append(str, ","); 
}

// helper to convert long to string
extern char* ltoa(unsigned long num, char* str) {
    char* p = str;
    unsigned long tmp = num;
    
    // Calculate length
    do {
        p++;
        tmp /= 10;
    } while (tmp);
    
    char* end = p;
    *p-- = '\0';
    
    // Fill digits backward
    do {
        *p-- = (num % 10) + '0';
        num /= 10;
    } while (num);
    
    return end; // returns pointer to null terminator
}

// Minimal sprintf supporting only %lu and strings
void mini_sprintf_telemetry(char* out, unsigned long rx, unsigned long tx, unsigned long err, unsigned long buf) {
    char* p = out;
    
    // Hardcoded JSON structure for speed and safety
    char* parts[] = {"{\"rx\": ", ", \"tx\": ", ", \"err\": ", ", \"buf\": ", "}"};
    
    unsigned long values[] = {rx, tx, err, buf};
    
    for(int i = 0; i < 4; i++) {
        // Copy label
        char* l = parts[i];
        while(*l) *p++ = *l++;
        // Copy value
        p = ltoa(values[i], p);
    }
    
    // Final closing brace
    char* last = parts[4];
    while(*last) *p++ = *last++;
    *p = '\0';
}