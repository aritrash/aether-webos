#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>

void timer_init(void);

#endif